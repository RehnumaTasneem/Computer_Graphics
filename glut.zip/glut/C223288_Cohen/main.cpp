//Cohen�Sutherland
#include <GL/glut.h>
#include <iostream>
using namespace std;
// Region codes
const int INSIDE = 0;
const int LEFT   = 1;
const int RIGHT  = 2;
const int BOTTOM = 4;
const int TOP    = 8;

double xMin, yMin, xMax, yMax;
double x1, y1, x2, y2;
double cx1, cy1, cx2, cy2;
bool accepted = false;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    // Draw clipping window
    glColor3f(1, 1, 1);
    glBegin(GL_LINE_LOOP);
        glVertex2d(xMin, yMin);
        glVertex2d(xMax, yMin);
        glVertex2d(xMax, yMax);
        glVertex2d(xMin, yMax);
    glEnd();
    // Draw original line (red)
    glColor3f(1, 0, 0);
    glBegin(GL_LINES);
        glVertex2d(x1, y1);
        glVertex2d(x2, y2);
    glEnd();
    // Draw clipped line (green)
    if (accepted) {
        glColor3f(0, 1, 0);
        glBegin(GL_LINES);
            glVertex2d(cx1, cy1);
            glVertex2d(cx2, cy2);
        glEnd();
    }
    glutSwapBuffers();
}
void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, 0, h);
}
void initGL() {
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
}
int main(int argc, char** argv) {

    cout << "Enter clipping window (xMin yMin xMax yMax): ";
    cin >> xMin >> yMin >> xMax >> yMax;
    cout << "Enter line endpoints (x1 y1 x2 y2): ";
    cin >> x1 >> y1 >> x2 >> y2;
    cx1 = x1; cy1 = y1;
    cx2 = x2; cy2 = y2;
    // Cohen�Sutherland logic directly here
    int out1, out2;
    while (true) {
        out1 = 0; out2 = 0;
        // OUTCODE of point 1
        if (cx1 < xMin) out1 |= LEFT;
        else if (cx1 > xMax) out1 |= RIGHT;
        if (cy1 < yMin) out1 |= BOTTOM;
        else if (cy1 > yMax) out1 |= TOP;

        // OUTCODE of point 2
        if (cx2 < xMin) out2 |= LEFT;
        else if (cx2 > xMax) out2 |= RIGHT;
        if (cy2 < yMin) out2 |= BOTTOM;
        else if (cy2 > yMax) out2 |= TOP;

        if ((out1 | out2) == 0) {
            accepted = true;
            break;
        }
        else if (out1 & out2) {
            accepted = false;
            break;
        }
        else {
            int outcodeOut = out1 ? out1 : out2;
            double x, y;

            if (outcodeOut & TOP) {
                x = cx1 + (cx2 - cx1) * (yMax - cy1) / (cy2 - cy1);
                y = yMax;
            } else if (outcodeOut & BOTTOM) {
                x = cx1 + (cx2 - cx1) * (yMin - cy1) / (cy2 - cy1);
                y = yMin;
            } else if (outcodeOut & RIGHT) {
                y = cy1 + (cy2 - cy1) * (xMax - cx1) / (cx2 - cx1);
                x = xMax;
            } else {
                y = cy1 + (cy2 - cy1) * (xMin - cx1) / (cx2 - cx1);
                x = xMin;
            }

            if (outcodeOut == out1) {
                cx1 = x; cy1 = y;
            } else {
                cx2 = x; cy2 = y;
            }
        }
    }
    if (accepted)
        cout << "Clipped line: (" << cx1 << ", " << cy1 << ") to (" << cx2 << ", " << cy2 << ")\n";
    else
        cout << "Line rejected.\n";
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize(640, 480);
    glutCreateWindow("Simple Cohen�Sutherland");

    initGL();
    glutDisplayFunc(display);
    glutReshapeFunc(reshape);

    glutMainLoop();
}
