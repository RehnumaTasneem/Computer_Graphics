#include <GL/freeglut.h>
#include <stdio.h>
#include <math.h>
#include <cstdlib>

float startX, startY, endX, endY;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0f, 1.0f, 0.0f);
    glPointSize(4.0f);
    glBegin(GL_POINTS);

    float dx = endX - startX;
    float dy = endY - startY;
    float steps = fabs(dx) > fabs(dy) ? fabs(dx) : fabs(dy);
    float xInc = dx / steps;
    float yInc = dy / steps;
    float x = startX;
    float y = startY;

    for (int i = 0; i <= steps; i++) {
        glVertex2f(x / 100.0f, y / 100.0f);
        x += xInc;
        y += yInc;
    }
    glEnd();
    glFlush();
}
void init() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}
int main(int argc, char** argv) {
    printf("Enter X1: "); scanf("%f", &startX);
    printf("Enter Y1: "); scanf("%f", &startY);
    printf("Enter X2: "); scanf("%f", &endX);
    printf("Enter Y2: "); scanf("%f", &endY);

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(700, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("DDA Line Drawing Algorithm");
    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
