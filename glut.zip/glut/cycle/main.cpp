#include <GL/glut.h>
#include <cmath>

void drawCycle() {
    int i;
    float x, y;

    // Wheels (black)
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_LINE_LOOP);
    for(i = 0; i < 360; i++) {
        float rad = i * 3.14159 / 180;
        x = 0.3 * cos(rad) - 0.3;
        y = 0.3 * sin(rad) - 0.3;
        glVertex2f(x, y);
    }
    glEnd();

    glBegin(GL_LINE_LOOP);
    for(i = 0; i < 360; i++) {
        float rad = i * 3.14159 / 180;
        x = 0.3 * cos(rad) + 0.3;
        y = 0.3 * sin(rad) - 0.3;
        glVertex2f(x, y);
    }
    glEnd();

    // Frame (red)
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_LINES);
        glVertex2f(-0.3, -0.3);
        glVertex2f(0.0, 0.3);
        glVertex2f(0.0, 0.3);
        glVertex2f(0.3, -0.3);
        glVertex2f(-0.3, -0.3);
        glVertex2f(0.3, -0.3);
    glEnd();
}

void displayCycle() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawCycle();
    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Cycle");
    glutDisplayFunc(displayCycle);
    glutMainLoop();
    return 0;
}
