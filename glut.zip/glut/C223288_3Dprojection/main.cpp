#include <GL/glut.h>

float angle = 0.0f; // Rotation angle

void init() {
    glClearColor(1.0, 1.0, 1.0, 1.0); // White background
    glEnable(GL_DEPTH_TEST);          // Enable depth testing
}

void drawAxes() {
    glBegin(GL_LINES);
    // X axis - red
    glColor3f(1, 0, 0);
    glVertex3f(-2, 0, 0);
    glVertex3f(2, 0, 0);
    // Y axis - green
    glColor3f(0, 1, 0);
    glVertex3f(0, -2, 0);
    glVertex3f(0, 2, 0);
    // Z axis - blue
    glColor3f(0, 0, 1);
    glVertex3f(0, 0, -2);
    glVertex3f(0, 0, 2);
    glEnd();
}

void drawWireCube() {
    glColor3f(0, 0, 0); // Cube edges black
    glutWireCube(2.0);   // Cube of size 2 (centered at origin)
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glTranslatef(0.0f, 0.0f, -6.0f); // Move back
    glRotatef(angle, 1.0f, 1.0f, 0.0f);

    drawAxes();       // Draw XYZ axes
    drawWireCube();   // Draw wireframe cube

    glutSwapBuffers();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(45.0, (float)w / (float)h, 0.1, 100.0);
}

void timer(int value) {
    angle += 1.0f;
    if (angle > 360.0f) angle = 0.0f;

    glutPostRedisplay();
    glutTimerFunc(16, timer, 0); // ~60 FPS
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Wireframe Cube with Axes");

    init();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutTimerFunc(0, timer, 0);

    glutMainLoop();
    return 0;
}
