#include <GL/freeglut.h>
#include <stdio.h>
#include <cstdlib>

int x1, y1, x2, y2;

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0f, 1.0f, 0.0f);
    glPointSize(3.0f);
    glBegin(GL_POINTS);
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int x = x1;
    int y = y1;
    int sx = (x2 > x1) ? 1 : -1;
    int sy = (y2 > y1) ? 1 : -1;
    bool isSteep = dy > dx;

    if (isSteep) {
        int p = 2 * dx - dy;
        for (int i = 0; i <= dy; i++) {
            glVertex2f(x / 50.0f, y / 50.0f);
            y += sy;
            if (p < 0)
                p += 2 * dx;
            else {
                x += sx;
                p += 2 * (dx - dy);
            }
        }
    } else {
        int p = 2 * dy - dx;
        for (int i = 0; i <= dx; i++) {
            glVertex2f(x / 100.0f, y / 100.0f);
            x += sx;
            if (p < 0)
                p += 2 * dy;
            else {
                y += sy;
                p += 2 * (dy - dx);
            }
        }
    }
    glEnd();
    glFlush();
}
void init() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}
int main(int argc, char** argv) {
    printf("Enter X1: "); scanf("%d", &x1);
    printf("Enter Y1: "); scanf("%d", &y1);
    printf("Enter X2: "); scanf("%d", &x2);
    printf("Enter Y2: "); scanf("%d", &y2);

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(700, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Bresenham's Line Drawing");
    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
