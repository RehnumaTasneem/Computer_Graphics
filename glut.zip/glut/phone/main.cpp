#include <GL/glut.h>

void drawPhone() {
    // Body (black)
    glColor3f(1.0, 1.0, 1.0);
    glBegin(GL_POLYGON);
        glVertex2f(-0.1, -0.3);
        glVertex2f(0.1, -0.3);
        glVertex2f(0.1, 0.3);
        glVertex2f(-0.1, 0.3);
    glEnd();

    // Screen (grey)
    glColor3f(0.5, 0.5, 0.5);
    glBegin(GL_POLYGON);
        glVertex2f(-0.09, -0.28);
        glVertex2f(0.09, -0.28);
        glVertex2f(0.09, 0.28);
        glVertex2f(-0.09, 0.28);
    glEnd();
}

void displayPhone() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawPhone();
    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Phone");
    glutDisplayFunc(displayPhone);
    glutMainLoop();
    return 0;
}
