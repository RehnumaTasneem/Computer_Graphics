#include <GL/glut.h>
#include <iostream>
#include <cmath>
using namespace std;

int x1_input, y1_input, x2_input, y2_input;

void plot(int x, int y) {
    glVertex2f(x / 10.0f, y / 10.0f);
    cout << "(" << x << ", " << y << ")\n";
}

void bresenham(int x1, int y1, int x2, int y2) {
    int dx = abs(x2 - x1);
    int dy = abs(y2 - y1);
    int p = 2 * dy - dx;

    int x = x1, y = y1;
    int x_inc = (x2 > x1) ? 1 : -1;
    int y_inc = (y2 > y1) ? 1 : -1;

    cout << "\nPlotted Points:\n";
    while (x != x2 || y != y2) {
        plot(x, y);
        if (p >= 0) {
            y += y_inc;
            p -= 2 * dx;
        }
        x += x_inc;
        p += 2 * dy;
    }
    plot(x2, y2); \
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_POINTS);
    bresenham(x1_input, y1_input, x2_input, y2_input);
    glEnd();
    glFlush();
}

int main(int argc, char** argv) {
    cout << "Enter x1 y1: ";
    cin >> x1_input >> y1_input;
    cout << "Enter x2 y2: ";
    cin >> x2_input >> y2_input;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Bresenham Line Drawing");

    glClearColor(0, 0, 0, 0);
    glColor3f(1, 1, 1);
    gluOrtho2D(-10, 10, -10, 10);

    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
