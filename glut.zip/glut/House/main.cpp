#include <GL/glut.h>

void drawHome() {
    // Base
    glColor3f(0.6, 0.4, 0.8);
    glBegin(GL_POLYGON);
        glVertex2f(-0.5, -0.5);
        glVertex2f(0.5, -0.5);
        glVertex2f(0.5, 0.0);
        glVertex2f(-0.5, 0.0);
    glEnd();

    // Roof
    glColor3f(1.0, 0.0, 0.0);
    glBegin(GL_TRIANGLES);
        glVertex2f(-0.6, 0.0);
        glVertex2f(0.6, 0.0);
        glVertex2f(0.0, 0.5);
    glEnd();
}

void displayHome() {
    glClear(GL_COLOR_BUFFER_BIT);
    drawHome();
    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Home");
    glutDisplayFunc(displayHome);
    glutMainLoop();
    return 0;
}
