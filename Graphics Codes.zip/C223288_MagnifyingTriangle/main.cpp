#include <GL/glut.h>
#include <cmath>

// Scale factor for magnified triangle
float scaleFactor = 1.0f;

// Triangle size
float size = 0.25f;

// Magnification point (triangle center)
float px = 0.0f;
float py = -size / 3.0f; // geometric center of triangle

// Draw triangle outline
void drawTriangle(float s)
{
    glBegin(GL_LINE_LOOP);
        glVertex2f(0.0f,  s);     // Top
        glVertex2f(-s, -s);       // Bottom Left
        glVertex2f( s, -s);       // Bottom Right
    glEnd();
}

// Display function
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    // Original triangle (black)
    glColor3f(0, 0, 0);
    drawTriangle(size);

    // Magnified triangle (red)
    glPushMatrix();
        glTranslatef(px, py, 0.0f);
        glScalef(scaleFactor, scaleFactor, 1.0f);
        glTranslatef(-px, -py, 0.0f);

        glColor3f(1, 0, 0);
        drawTriangle(size);
    glPopMatrix();

    // Magnification point (red dot)
    glColor3f(1, 0, 0);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
        glVertex2f(px, py);
    glEnd();

    glFlush();
}

// Keyboard controls
void keyboard(unsigned char key, int x, int y)
{
    if (key == '+')
        scaleFactor += 0.1f;

    if (key == '-')
        scaleFactor -= 0.1f;

    if (scaleFactor < 1.0f)
        scaleFactor = 1.0f;

    glutPostRedisplay();
}

// Initialization
void init()
{
    glClearColor(1, 1, 1, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);

    glMatrixMode(GL_MODELVIEW);
}

// Main
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("Triangle Magnification");

    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
