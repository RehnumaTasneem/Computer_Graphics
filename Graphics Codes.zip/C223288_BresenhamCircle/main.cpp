#include <GL/freeglut.h>
#include <iostream>
#include <cstdlib>
using namespace std;

int xc, yc, r;

void plotCirclePoints(int x, int y) {
    glVertex2f((xc + x) / 100.0f, (yc + y) / 100.0f);
    glVertex2f((xc - x) / 100.0f, (yc + y) / 100.0f);
    glVertex2f((xc + x) / 100.0f, (yc - y) / 100.0f);
    glVertex2f((xc - x) / 100.0f, (yc - y) / 100.0f);
    glVertex2f((xc + y) / 100.0f, (yc + x) / 100.0f);
    glVertex2f((xc - y) / 100.0f, (yc + x) / 100.0f);
    glVertex2f((xc + y) / 100.0f, (yc - x) / 100.0f);
    glVertex2f((xc - y) / 100.0f, (yc - x) / 100.0f);
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1, 1, 1);
    glPointSize(3.0f);

    glBegin(GL_POINTS);

    int x = 0;
    int y = r;
    int p = 3 - 2 * r;

    while (x <= y) {
        plotCirclePoints(x, y);
        if (p < 0) p += 4 * x + 6;
        else {
            p += 4 * (x - y) + 10;
            y--;
        }
        x++;
    }
    glEnd();
    glFlush();
}
void init() {
    glClearColor(0, 0, 0, 0);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, 1, 0, 1, -1, 1);
}
int main(int argc, char** argv) {
    cout << "Enter circle center X Y: ";
    cin >> xc >> yc;
    cout << "Enter radius: ";
    cin >> r;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(700, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Bresenham Circle Drawing");
    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
