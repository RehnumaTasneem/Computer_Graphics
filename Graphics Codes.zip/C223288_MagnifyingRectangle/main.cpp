#include <GL/glut.h>

// Scale factor
float scaleFactor = 1.0f;

// Rectangle size
float width = 0.3f;
float height = 0.2f;

// Magnification point (rectangle center)
float px = 0.0f;
float py = 0.0f;

// Draw rectangle outline
void drawRectangle(float w, float h)
{
    glBegin(GL_LINE_LOOP);
        glVertex2f(-w, -h);
        glVertex2f( w, -h);
        glVertex2f( w,  h);
        glVertex2f(-w,  h);
    glEnd();
}

// Display function
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();

    // Original rectangle (black)
    glColor3f(0, 0, 0);
    drawRectangle(width, height);

    // Magnified rectangle (red)
    glPushMatrix();
        glTranslatef(px, py, 0.0f);
        glScalef(scaleFactor, scaleFactor, 1.0f);
        glTranslatef(-px, -py, 0.0f);

        glColor3f(1, 0, 0);
        drawRectangle(width, height);
    glPopMatrix();

    // Magnification point (red dot)
    glColor3f(1, 0, 0);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
        glVertex2f(px, py);
    glEnd();

    glFlush();
}

// Keyboard controls
void keyboard(unsigned char key, int x, int y)
{
    if (key == '+')
        scaleFactor += 0.1f;

    if (key == '-')
        scaleFactor -= 0.1f;

    if (scaleFactor < 1.0f)
        scaleFactor = 1.0f;

    glutPostRedisplay();
}

// Initialization
void init()
{
    glClearColor(1, 1, 1, 1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);

    glMatrixMode(GL_MODELVIEW);
}

// Main
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("Rectangle Magnification");

    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
