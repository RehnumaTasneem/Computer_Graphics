#include <GL/glut.h>
#include <cmath>

// Scale factor for magnified circle
float scaleFactor = 1.0f;

// Circle center (magnification point)
float px = 0.0f;
float py = 0.0f;

// Draw circle outline
void drawCircle(float r)
{
    glBegin(GL_LINE_LOOP);
    for (int i = 0; i < 100; i++)
    {
        float theta = 2.0f * 3.1416f * i / 100;
        glVertex2f(r * cos(theta), r * sin(theta));
    }
    glEnd();
}
// Display function
void display()
{
    glClear(GL_COLOR_BUFFER_BIT);
    glLoadIdentity();
    // Main circle (black)
    glColor3f(0,0,0);
    drawCircle(0.2f);

    // Magnified circle (red)
    glPushMatrix();
        glTranslatef(px, py, 0.0f);
        glScalef(scaleFactor, scaleFactor, 1.0f);
        glTranslatef(-px, -py, 0.0f);

        glColor3f(1,0,0);
        drawCircle(0.2f);
    glPopMatrix();

    // Center point (RED)
    glColor3f(1.0f, 0.0f, 0.0f);
    glPointSize(6.0f);
    glBegin(GL_POINTS);
        glVertex2f(px, py);
    glEnd();

    glFlush();
}
// Keyboard controls
void keyboard(unsigned char key, int x, int y)
{
    if (key == '+')
        scaleFactor += 0.1f;

    if (key == '-')
        scaleFactor -= 0.1f;

    // Prevent smaller than original
    if (scaleFactor < 1.0f)
        scaleFactor = 1.0f;

    glutPostRedisplay();
}
// Initialization
void init()
{
    // BLACK background
    glClearColor(1,1,1,1);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-1, 1, -1, 1);

    glMatrixMode(GL_MODELVIEW);
}
// Main
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitWindowSize(600, 600);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutCreateWindow("Circle Magnification");

    init();
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);

    glutMainLoop();
    return 0;
}
