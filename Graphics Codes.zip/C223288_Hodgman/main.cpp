//sutherland-Hodgman Clipping
#include <GL/glut.h>
#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct Vec2 { double x, y; };

vector<Vec2> subjectPolygon, clipWindow, clippedPolygon;

double cross(Vec2 a, Vec2 b, Vec2 c) {
    return (b.x - a.x)*(c.y - a.y) - (b.y - a.y)*(c.x - a.x);
}
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    // Draw clipping window (blue)
    glColor3f(0,0,1);
    glBegin(GL_LINE_LOOP);
    for(auto &p: clipWindow) glVertex2d(p.x, p.y);
    glEnd();
    // Draw original polygon (red)
    glColor3f(1,0,0);
    glBegin(GL_LINE_LOOP);
    for(auto &p: subjectPolygon) glVertex2d(p.x, p.y);
    glEnd();
    // Draw clipped polygon (green)
    glColor3f(0,1,0);
    glBegin(GL_POLYGON);
    for(auto &p: clippedPolygon) glVertex2d(p.x, p.y);
    glEnd();
    glFlush();
}
int main(int argc, char** argv) {
    int n;
    cout << "Enter number of polygon vertices: ";
    cin >> n;
    subjectPolygon.resize(n);
    cout << "Enter polygon vertices (x y):\n";
    for(int i=0;i<n;i++) cin >> subjectPolygon[i].x >> subjectPolygon[i].y;

    double xmin, ymin, xmax, ymax;
    cout << "Enter clipping window (xmin ymin xmax ymax): ";
    cin >> xmin >> ymin >> xmax >> ymax;
    // Define clipping window vertices (CCW)
    clipWindow = { {xmin, ymin}, {xmin, ymax}, {xmax, ymax}, {xmax, ymin} };
    // Start clipping polygon
    clippedPolygon = subjectPolygon;
    for(int i=0;i<4;i++) {
        Vec2 A = clipWindow[i];
        Vec2 B = clipWindow[(i+1)%4];
        vector<Vec2> output;
        int m = clippedPolygon.size();
        for(int j=0;j<m;j++) {
            Vec2 current = clippedPolygon[j];
            Vec2 next = clippedPolygon[(j+1)%m];
            double currCross = cross(A,B,current);
            double nextCross = cross(A,B,next);

            auto intersection = Vec2{0,0};
            if((currCross >=0 && nextCross >=0)) {
                output.push_back(next);
            } else if(currCross >=0 && nextCross <0) {
                // compute intersection
                double dx = next.x - current.x;
                double dy = next.y - current.y;
double t = ((A.x - current.x)*(A.y - B.y) - (A.y - current.y)*(A.x - B.x)) / ((dx)*(A.y - B.y) - (dy)*(A.x - B.x));
                intersection.x = current.x + t*dx;
                intersection.y = current.y + t*dy;
                output.push_back(intersection);
            } else if(currCross <0 && nextCross >=0) {
                double dx = next.x - current.x;
                double dy = next.y - current.y;
double t = ((A.x - current.x)*(A.y - B.y) - (A.y - current.y)*(A.x - B.x)) / ((dx)*(A.y - B.y) - (dy)*(A.x - B.x));
                intersection.x = current.x + t*dx;
                intersection.y = current.y + t*dy;
                output.push_back(intersection);
                output.push_back(next);
            }
        }
        clippedPolygon = output;
    }
    // OpenGL setup
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(600,600);
    glutCreateWindow("Simple Sutherland-Hodgman Clipping");

    glClearColor(1,1,1,1);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0,400,0,400);

    glutDisplayFunc(display);
    glutMainLoop();
}
